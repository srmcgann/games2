<?php
  //error_reporting(0);
  $db_user  = 'id21284549_user';
  $db_pass  = 'Chrome57253!*';
  $db_host  = 'localhost';
  $db       = "id21284549_videodemos2";
  $port     = '3306';
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);

  $baseURL  = "http://games2.whitehot.ninja/b/games/tetris";
  $link     = mysqli_connect($db_host,$db_user,$db_pass,$db,$port);
?>
